package com.example.abgabedocker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbgabeDockerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbgabeDockerApplication.class, args);
	}

}
