package com.example.abgabedocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbgabeDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
